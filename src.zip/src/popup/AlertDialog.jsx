import React from 'react';

const Alertdialog = () => {
    return (
        <>
          <div className="alert_dialog">
            
           </div>  
        </>
    );
}

export default Alertdialog;
