const EditComment = () => {
    return {
        type: "SetEditComment"
    }
}