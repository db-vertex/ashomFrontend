export const insertUserdata = () => {
    return {
        type: "INSERTUSERDATA"
    }
}

export const updateUserdata = () => {
    return {
        type: "UPDATEUSERDATA"
    }
}